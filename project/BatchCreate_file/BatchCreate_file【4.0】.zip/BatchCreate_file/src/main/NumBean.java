package main;

/**����ʱ�䣺 2016.11.27
 * 
 * 	JavaBena��ÿһ�����
 * 			@author Suvan
 *
 */
public class NumBean {
	
		private String num;				//��վ����Դ���롾��š�
		private String area;			    //����
		private String province;		//ʡ��
		private String city;				    //����
		private String county;		    //����
		private String webname;      //��վ����Դ����
		private String weburl;			//��ַ
		private String infsource;	    //��Ϣ��Դ
		private String inftype;			//��Ϣ����
		private String worktype;		//��ҵ����
		private String zbyg;				//�б�Ԥ��
		private String zbgg;				//�б깫��
		private String zsjg;			    //������
		private String ggbg;				//������
		private String zbwj;				//�б��ļ�
		private String zbdy;				//�б����
		private String zbxx;				//�б���Ϣ
		private String kzj;					//���Ƽ�
		private String lot;					//����
		private String webtype;		//ԭ��վ��Ϣ����
		private String remark;			//��ע
	
			public String getNum() {
				return num;
			}
			public String getArea() {
				return area;
			}
			public String getProvince() {
				return province;
			}
			public String getCity() {
				return city;
			}
			public String getCounty() {
				return county;
			}
			public String getWebname() {
				return webname;
			}
			public String getWeburl() {
				return weburl;
			}
			public String getInfsource() {
				return infsource;
			}
			public String getInftype() {
				return inftype;
			}
			public String getWorktype() {
				return worktype;
			}
			public String getZbyg() {
				return zbyg;
			}
			public String getZbgg() {
				return zbgg;
			}
			public String getZsjg() {
				return zsjg;
			}
			public String getGgbg() {
				return ggbg;
			}
			public String getZbwj() {
				return zbwj;
			}
			public String getZbdy() {
				return zbdy;
			}
			public String getZbxx() {
				return zbxx;
			}
			public String getKzj() {
				return kzj;
			}
			public String getLot() {
				return lot;
			}
			public String getWebtype() {
				return webtype;
			}
			public String getRemark() {
				return remark;
			}
			public void setNum(String num) {
				this.num = num;
			}
			public void setArea(String area) {
				this.area = area;
			}
			public void setProvince(String province) {
				this.province = province;
			}
			public void setCity(String city) {
				this.city = city;
			}
			public void setCounty(String county) {
				this.county = county;
			}
			public void setWebname(String webname) {
				this.webname = webname;
			}
			public void setWeburl(String weburl) {
				this.weburl = weburl;
			}
			public void setInfsource(String infsource) {
				this.infsource = infsource;
			}
			public void setInftype(String inftype) {
				this.inftype = inftype;
			}
			public void setWorktype(String worktype) {
				this.worktype = worktype;
			}
			public void setZbyg(String zbyg) {
				this.zbyg = zbyg;
			}
			public void setZbgg(String zbgg) {
				this.zbgg = zbgg;
			}
			public void setZsjg(String zsjg) {
				this.zsjg = zsjg;
			}
			public void setGgbg(String ggbg) {
				this.ggbg = ggbg;
			}
			public void setZbwj(String zbwj) {
				this.zbwj = zbwj;
			}
			public void setZbdy(String zbdy) {
				this.zbdy = zbdy;
			}
			public void setZbxx(String zbxx) {
				this.zbxx = zbxx;
			}
			public void setKzj(String kzj) {
				this.kzj = kzj;
			}
			public void setLot(String lot) {
				this.lot = lot;
			}
			public void setWebtype(String webtype) {
				this.webtype = webtype;
			}
			public void setRemark(String remark) {
				this.remark = remark;
			}
}
