package com.bonait.dataextract.service.impl;
import javax.annotation.Resource;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Service;

import com.bonait.dataextract.dao.BaseDao;
import com.bonait.dataextract.domain.*;
import com.bonait.dataextract.service.*;
import com.bonait.dataextract.util.Util;
import com.bonait.dataextract.vo.*;


/**
 * @程序猿：刘淑玮
 * 
 * @内容：东软一期-政府采购-中标信息-03151
 */
@Service("shanghai_03100_ZhongbXxService")
public class CQ_00961_ZhongbXxService implements ZhongbXxService{

	@Resource
	private SessionFactory sf ;
	private Query query;
	private ZhongBiaoXinXi zbxx;
	//列表页接口地址
	private String listUrl="http://127.0.0.1:1626/?iw-apikey=123&iw-cmd=sichuang00181List&iw_ir_2=002002&page=";
	//内容页接口地址
	private String detailUrl="http://127.0.0.1:1626/?iw-apikey=123&iw-cmd=sichuang00181Detail&iw_ir_2=002002&InfoID=";
	//入库编码
	private String sourceNo="03151";
	@Override
	public void initZhongbXxService() {
		try{
		String s=Util.sendGet(listUrl,"1");
		JSONObject obj =JSONObject.fromObject(s);
		while (null == obj.get("pageCount")){
			s = Util.sendGet(listUrl, "1");
			obj = JSONObject.fromObject(s);
		}
//		if(obj.getString("list").length()<10){System.out.println(sourceNo+"列表为空，请检查一下接口。");return;}
		int maxPage=Integer.parseInt(obj.get("pageCount").toString());
//		int maxPage=723;
		Session session=sf.openSession();
		session.beginTransaction();
		//清空数据库里
//		query=session.createSQLQuery("DELETE FROM t_zhong_biao_xin_xi t where t.WEB_SOURCE_NO='"+sourceNo+"'");
//		query.executeUpdate();
//		session.getTransaction().commit();
//		session.beginTransaction();
		//
		int KK=0;
			flag:
			for(int i=1;i<=3;i++){//maxPage
				String jsonList=Util.sendGet(listUrl,i+"");
				JSONObject objList =JSONObject.fromObject(jsonList);
				while(null == objList.get("list")){
					jsonList = Util.sendGet(listUrl, i + "");
					objList = JSONObject.fromObject(jsonList);
				}
				JSONArray temp=(JSONArray) objList.get("list");
				List list = (List)JSONArray.toList(temp,ListVO.class);
				Iterator it = list.iterator();
				int rows = 1;
				for(int row =1;row < rows;row++){
					it.next();
				}
				while(it.hasNext()){
					ListVO listvo =(ListVO) it.next();
					query=session.createSQLQuery("SELECT ID FROM t_zhong_biao_xin_xi t where t.WEB_SOURCE_NO='"+sourceNo+"' and t.RECORD_ID='"+listvo.getId()+"'");
					String getDate=listvo.getDate();
					//获取页数，便于插入数据异常时，先跳过该页
					System.out.println(i+":"+getDate+":"+maxPage);
					
		        	int date = Integer.parseInt(getDate.substring(0, 4));
		        	//只取2014年至今的不重复数据	
				    if(query.executeUpdate()<=0&&date>=2014){
				    	KK+=1;
				    	String detail = null;
						JSONObject o = null;
						String content = null;
						while (content == null || content.length() < 10) {
							detail = Util.sendGet(detailUrl, listvo.getId());
							if (null != detail)
								o = JSONObject.fromObject(detail);
							else
								continue;
							if (null != o&&null != o.get("content"))
								content = o.get("content").toString();
							else
								continue;
							System.out.println("runing..");
						}
					    //过滤掉无效数据
					    if(content==null||content.length()<10||content.contains("出错")||content.contains("找不到文件")){continue;}
					    zbxx=new ZhongBiaoXinXi();
					    zbxx.setWebSourceNo(sourceNo);
					    zbxx.setArea("华东");//区域
					    zbxx.setProvince("上海");//省份
					    zbxx.setCity("上海");//城市，没有可不填
					    zbxx.setDistrict("太谷");// 区县 不要“区”字符
//					    zbxx.setCity(listvo.getCiy());
					    zbxx.setWebSourceName("太谷县政府采购网");//网站名称，写完整的名称
					    zbxx.setInfoSource("政府采购");//信息来源
					    //未匹配到工程或服务的，都标识为货物
			        	String infoType=Util.getInfoType(content);
			        	if(infoType!=null&&infoType.length()>0)
			        	zbxx.setInfoType(Util.getInfoType(content));
			        	else {zbxx.setInfoType("货物");}
//					    zbxx.setInfoType("服务");//信息类型
//					    zbxx.setIndustry("建筑建材"); //行业分类
//					    zbxx.setIndustry(Util.getIndustry(content));//行业分类
					    zbxx.setRecordId(listvo.getId());
					    zbxx.setId(UUID.randomUUID().toString());
					    zbxx.setPageTitle(listvo.getTitle());
					    zbxx.setPageTime(getDate);
					    zbxx.setPageContent(content);
					    zbxx.setPageAttachments("");//附件url，暂不需要
					    zbxx.setCreateTime(new Date());
						session.save(zbxx);
				     }else if(date<=2013){break flag;}//到2013年的页码时，断掉循环
				    if(KK%1==0){
				    	session.flush();  
				    	session.clear();
				    	session.getTransaction().commit();
				    	session.beginTransaction();
				    }
				}  
			}	
			
		session.getTransaction().commit();
		session.close();
		System.out.println("000000000");
		} catch (Exception e) {
			System.out.println(sourceNo+"接口出错，请检查");
		}
	}

}