package com.bonait.dataextract.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.annotation.Resource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Service;

import com.bonait.dataextract.domain.ZhaoBiaoGongGao;
import com.bonait.dataextract.service.ZhaobGgService;
import com.bonait.dataextract.util.Util;
import com.bonait.dataextract.util.Utils;
import com.bonait.dataextract.vo.AreaAndProvince;
import com.bonait.dataextract.vo.ListVO;


/**
 * @����Գ��//@����Գ;
 * 
 * @���ݣ�//@����;
 */
@Service("//ע��;")
public class //����; implements ZhaobGgService{

	@Resource
	private SessionFactory sf ;
	private Query query;
	private ZhaoBiaoGongGao zbgg;
	//�б�ҳ�ӿڵ�ַ
	private String listUrl="";
	//����ҳ�ӿڵ�ַ
	private String detailUrl="";
	//������
	private String sourceNo="//���;";
	
	@Override
	public void initZhaobGgService() {
		
		List<List<ListVO>> lists =new ArrayList<List<ListVO>>();
		Session session=sf.openSession();
		List<ListVO> list;
		JSONArray temp;
		session.beginTransaction();
		
		try{
            //��ȡ��ҳ��
		      String s=Util.sendGet(listUrl,"1");
		      JSONObject obj =JSONObject.fromObject(s);
		      int maxPage=Integer.parseInt(obj.get("pageCount").toString());
		      System.out.println("pageCount:" + maxPage);

				//������ݿ���
//				query=session.createSQLQuery("DELETE FROM //����; t where t.WEB_SOURCE_NO='"+sourceNo+"'");
//				query.executeUpdate();
//				session.getTransaction().commit();
//				session.beginTransaction();
		
		       
				int KK=0;
				int re;
					//maxPage ҳ��
					flag:for(int i=1;i<=maxPage;i++){
							String jsonList=Util.sendGet(listUrl,i+"");
							JSONObject objList =JSONObject.fromObject(jsonList);
							temp=(JSONArray) objList.get("list");
							list = (List<ListVO>)JSONArray.toList(temp,ListVO.class);
							query=session.createSQLQuery("SELECT ID FROM //����; t where t.WEB_SOURCE_NO='"+sourceNo+"' and t.RECORD_ID='"+list.get(0).getId()+"'");
							if(query.executeUpdate()<=0){
								lists.add(list);
							}else{
								break flag;
							}
					}
					if(lists.size()!=0)
						for(int i=lists.size()-1;i >= 0 ;i--){
								for(int j = lists.get(i).size()-1;j >= 0;j--){

									//ƥ����������
									query = session.createSQLQuery("SELECT ID FROM //����; t where t.WEB_SOURCE_NO='"+ sourceNo+ "' and t.PAGE_TITLE='"+ lists.get(i).get(j).getTitle() + "' and t.PAGE_TIME='"+lists.get(i).get(j).getDate()+"'");
									if (query.executeUpdate() > 0) {
										//ƥ��ID
										query = session.createSQLQuery("SELECT ID FROM //����; t where t.WEB_SOURCE_NO='"+ sourceNo+ "' and t.RECORD_ID='"+ lists.get(i).get(j).getId() + "'");
										if(query.executeUpdate() <= 0){
											//����ͬ�������2λ����
											Random ss = new Random();
											re = ss.nextInt(100);
											lists.get(i).get(j).setTitle(lists.get(i).get(j).getTitle()+"-"+re);
										}else{
											continue;
										}
									}
									System.out.println(lists.get(i).get(j).getDate());
					
									int date = Integer.parseInt(lists.get(i).get(j).getDate().substring(0, 4));
									
									//ֻȡ2014�����������
									if(date>=2014){
								    	KK+=1;
								    	String detail = Util.sendGet(detailUrl, lists.get(i).get(j).getId());
										JSONObject o=JSONObject.fromObject(detail);
										String content=o.get("content").toString();
									    //���˵���Ч����
										 if (content == null || content.length() < 10 || content.contains("����") || content.contains("�Ҳ����ļ�"))
											{
												continue;
											}
										 List<AreaAndProvince> plist = Util.contiansProvince(lists.get(i).get(j).getTitle());
										for (int x = 0; x < plist.size(); x++) {
												AreaAndProvince areaAndProvince = plist.get(x);
												
											    zbgg=new ZhaoBiaoGongGao();
											    zbgg.setWebSourceNo(sourceNo);
											    zbgg.setArea("//Area;");//����
											    zbgg.setProvince("//Province;");//ʡ��
											    zbgg.setCity("//City;");//���У�û�пɲ���
											    zbgg.setDistrict("//County;");// ���� ��Ҫ�������ַ�
											    zbgg.setWebSourceName("//Webname;");//��վ���ƣ�д����������
											    zbgg.setInfoSource("//Infsource;");//��Ϣ��Դ
					    
											    //δƥ�䵽���̻����ģ�����ʶΪ����
									        	String infoType=Util.getInfoType(content);
									        	if (infoType != null && infoType.length() > 0)
									        		zbgg.setInfoType(Util.getInfoType(content));
												else
												{
													zbgg.setInfoType("����");
												}
									        	//�Ƿ�����Ϣ����;
							        	
									        	zbgg.setIndustry(Util.getIndustry(content));//��ҵ����,�Զ�ƥ��
									        	//�Ƿ�����ҵ����;
		
											    zbgg.setRecordId(lists.get(i).get(j).getId());
											    zbgg.setId(UUID.randomUUID().toString());
											    zbgg.setPageTitle(lists.get(i).get(j).getTitle());
											    zbgg.setPageTime(lists.get(i).get(j).getDate());
												//listû��ʱ���������������
//											    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//												zbgg.setPageTime(sdf.format(new Date()));
											    zbgg.setPageContent(content);
											    zbgg.setPageAttachments("");//����url���ݲ���Ҫ
											    zbgg.setCreateTime(new Date());
												session.save(zbgg);
										}
									}
								    if(KK % 1 == 0){
								    	session.flush();  
								    	session.clear();
								    	session.getTransaction().commit();
								    	session.beginTransaction();
								    }
							}  
					}	
		} catch (Exception e) {
			System.out.println(sourceNo+" is error, please cheak ZhaobGgService !!!!!!!");
		}
		session.getTransaction().commit();
		session.close();
		System.out.println("000000000");
	}

}