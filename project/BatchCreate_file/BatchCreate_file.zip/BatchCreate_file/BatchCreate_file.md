---
title: BatchCreate_file
date: 2016-8-27 9:25:43
tags: MyProject
categories: MyProject
---


前言
====================================
用时2天半左右，写了一个批量生成目录文件的小项目
不算太简洁

自己写了一些基础,常用的method，封装进不同的类里

一.用于测试的主方法: *testMain.java*
二.任务流程: *TaskFlow.java*
三.连接，操作数据库：*UseDB*
四.操作文件,目录：*IOFile.java*
五.创建文件，改变文件内容: *ChangeFile.java*
六.两套相关模版:
七.设计数据库:


目的是为了重点巩固基础，如果有错误或者逻辑比较混乱的地方，欢迎探讨指出^_^

---


代码
============================

一.testMain.java
-------------------
```
package review;

public class testMain {
  

  //main()方法，测试
  public static void main(String [] args){
  
    //创建任务流程对象
    TaskFlow tf= new TaskFlow();
    
    //执行流程(参数:路径,目录名)
    tf.GO("C:/Users/Liu-shuwei/Desktop\\","刘淑玮-第二批(03069-03127)","SX");

      
  }
}

```

---


二.TaskFlow.java
-----------------------
```
package review;

public class TaskFlow {
  
  public static long  useTime(){
    return System.currentTimeMillis();
  }
  
  //无参构造方法
  public TaskFlow(){
    
    
  }
  
  //任务流程
  public void GO(String path,String name,String province) {
    //开始时间
    long beginTime=useTime();
    
    //执行任务流程
    try{
      UseDB udb = new UseDB();
      IOFile iof=new IOFile();
      
      udb.connDatabase();//连接数据库
      
      //一.往数据库插入模版数据
      String content=null;                                      //注意，路径的话用/或者\\都可以
      content=iof.readFileContent("C:/Users/Liu-shuwei/Desktop/模版文档(修改过)/BackupTask.java","UTF-8"); //数据库的默认编码是GBK,如果是UTF-8\
      udb.insertTXT("article","model,detail","BackupTask&&&&&"+content,"?,?");
      content=iof.readFileContent("C:/Users/Liu-shuwei/Desktop/模版文档(修改过)/ZhaobGgServiceModel.java","UTF-8"); 
      udb.insertTXT("article","model,detail","ZhaobGgServiceModel&&&&&"+content,"?,?");

      
      //二.创建整体目录
      iof.cList(path,name,province);
      
      //关闭资源
      udb.closeAll();
      
    }catch(Exception e){
      e.printStackTrace();
    }
    
    //结束时间
    long endTime=useTime();
    System.out.println("总共用时:"+(endTime-beginTime)+"毫秒！");
  }
}

```

---


三.UseDB.java
-------------
```
package review;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class UseDB {
  
  
  private String drive="com.mysql.jdbc.Driver";           //数据库驱动
  private String link="jdbc:mysql://127.0.0.1:3306/";     //mysql—JDBC链接+IP地址+端口
  private String database="my_blog";                      //数据库
  
  private String username="root";                         //用户名
  private String password="123";            //密码
  
  private Connection conn;
  private Statement st;
  private PreparedStatement pst;
  private ResultSet rs;
  private ResultSetMetaData rsmd;//获取列的信息
  
  private String sql; //sql语句
  

  //无参构造方法，创建UseDB对象时候，直接连接数据库
  public UseDB(){ 

  }
  
  //调用该方法时候连接数据库
  public void connDatabase()  throws Exception{
     Class.forName(drive);
     conn=DriverManager.getConnection(link+database,username,password); 
     st=conn.createStatement();
     System.out.println("数据库连接成功......");
  }

    //功能1: 使用database数据库                                
    public void useDatabase(String database){//参数: 数据库名称
      sql="USE "+database+";";
      try{
        rs=st.executeQuery(sql);
      }catch(Exception e){
        e.printStackTrace();
      }
      System.out.println(sql+" 执行完毕！-------------------------------------");
    }
    
    //功能2:查询table表中record字段满足condition条件的值
    public String select(String table,String record,String condition){//参数: 表名,字段名,WHERE条件
      
      StringBuilder sb= new StringBuilder();
      sql="SELECT "+record+" FROM " +table+" WHERE "+condition+";";
      
      try{
        rs=st.executeQuery(sql);
           ResultSetMetaData rsm =rs.getMetaData(); //获得列集
        while(rs.next()){
          sb.append(rs.getString(record));
        }

      }catch(Exception e){
        e.printStackTrace();
      }
      System.out.println(sql+" 执行完毕！-------------------------------------");
      return sb.toString();
    }
    
    //功能3:查询table所有数据的数据,打印到控制台
    public String selectAll(String table){//参数: 表名
      
      StringBuilder sb= new StringBuilder();
      sql="SELECT * FROM " +table+";";
      
      try{
        rs=st.executeQuery(sql);
        rsmd =rs.getMetaData(); //获得列集
        while(rs.next()){
          for(int i=1;i<rsmd.getColumnCount();i++){
            System.out.print(rs.getString(i)+"\t");
          }
          System.out.println();//换行
        }

      }catch(Exception e){
        e.printStackTrace();
      }
      System.out.println(sql+" 执行完毕！-------------------------------------");
      return sb.toString();
    }

    
    //功能4:查询webapi表,判断招标预告到控制价字段的记录值是否存在URL  ,返回有URL记录的字段名(例如:zbgg)
    public String checktable(String num){//参数: 编号
      StringBuilder sb= new StringBuilder();
      sql="SELECT * FROM webapi WHERE num='"+num+"';";
      String content=null;
      try{
        rs=st.executeQuery(sql);
        rsmd=rs.getMetaData();
        while(rs.next()){
          for(int i=10;i<18;i++){
            content=rs.getString(i);
            if(content.length()<5) continue;
              
              sb.append(rsmd.getColumnName(i)+"&"); 
          }
        }
      
      }catch(SQLException e){
        e.printStackTrace();
      }
      System.out.println(sql+" 执行完毕！-------------------------------------");
      return sb.toString();
    }
    
    
    
    //功能5:查询table表,record字段的所有记录值(所有行)
    public String selectNum(String table,String record) throws SQLException{
      StringBuilder sb= new StringBuilder();
      
       sql="SELECT "+record+" FROM "+table+";";
       rs=st.executeQuery(sql);
       while(rs.next()){
         sb.append(rs.getString(1)+"&");
       }
       
      System.out.println(sql+" 执行完毕！-------------------------------------");
      return sb.toString();
    }
    
    
    
    
    //功能6: 插入数据--少量数据(标题，日期等)
    public void insert(String table,String record,String content){//参数: 表名,字段(多的话用,分割),内容(多的话用,号分割)
        String sql="INSERT INTO "+table+"("+record+") VALUES("+content+");";
          int i=0;
          try{
            i=st.executeUpdate(sql);
            
          }catch(Exception e){
            e.printStackTrace();
          }

          if(i!=-1){
            System.out.println("插入成功");
          }
        System.out.println(sql+"执行完毕！");
      }
    
    //功能7:插入数据--大量数据(文章，文本内容)
    public void insertTXT(String table,String record,String content,String mark){//参数值: 表名,字段,内容(多个内容用&号分割),?号(多个?用,分割)
      
      sql="INSERT INTO "+table+"("+record+") VALUES("+mark+");";
      
      String [] strA=content.split("&&&&&");
      //判断是否存在相同记录，如果存在则不执行插入
      String ifwhere=record.substring(0,record.indexOf(","));
      String ifexist="SELECT "+record+" FROM "+table+" WHERE "+ifwhere+"='"+strA[0]+"';";
        
      try{
        rs=st.executeQuery(ifexist);
        System.out.println(ifexist+" 执行完毕！================================");
        
        if(rs.next()){//存在相同记录
          System.out.println("数据库中已经存在相同"+strA[0]+"模版,不进行重复插入!");
        }else{
          //不存在相同记录
          System.out.println("数据库不存在"+strA[0]+"模版,正在进行插入......");
          pst=conn.prepareStatement(sql);
          
          for(int i=1;i<=strA.length;i++){//循环次数: ?号个数      
            pst.setString(i,strA[i-1]);
          }
          
          pst.executeUpdate();
        }

      }catch(Exception e){
        e.printStackTrace();
      }
      
      System.out.println(sql+" 执行完毕！================================");
    }
    
  
    
    
    
    //功能8: 查询数据库weiabi表中对应num编号整行记录的需求字段的信息(区域，省份，城市，区县，网站名称，信息来源)
    public String selectNeedInformation_num(String num){
        StringBuilder sb= new StringBuilder();
      
      sql="SELECT * FROM webapi WHERE num='"+num+"';";
      try{
        rs=st.executeQuery(sql);
        while(rs.next()){
          for(int i=2;i<=8;i++){ //区域-信息来源
            if(i==7) continue; //网站网址
            sb.append(rs.getString(i)+"&");
          }   
        }
      }catch(Exception e){
        e.printStackTrace();
      }
      
      System.out.println(sql+" 执行完毕！-------------------------------------");
      return sb.toString(); 
    }
    
    //关闭数据库连接
    public void closeAll(){
      
      //关闭Result
       try{
                if(rs!=null)
                     rs.close();
             }catch(Exception e){
                 e.printStackTrace(System.err);
             }
       
       
      //关闭PreparedStatement
      try{
      if(pst!=null)
                  pst.close();
            }catch(Exception e){
               e.printStackTrace(System.err);
            }
            
      
      //关闭Statement
       try{
                 if(st!=null)
                     st.close();
             }catch(Exception e){
                 e.printStackTrace(System.err);
             }
      
       
       //关闭Connection
           try{
               if(conn!=null)
                   conn.close();
           }catch(Exception e){
               e.printStackTrace(System.err);
           }
    
    }
}


```


---


四.IOFile.java
-------------------------------
```
package review;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class IOFile {
  
    //功能1:(字节流)读取文件内容--只适用与读取英文，数字，无法设置编码格式
    public String readFileContent2(String path) throws IOException{ //参数:路径
      String content="";
      
      InputStream inf=new FileInputStream(path);
      int size=inf.available();
      for(int i=0;i<size;i++){
        content+=(char)inf.read();
      }
      
      return "\'"+content+"\'"; 
    }
    
    //功能2:(字符流)读取文件内容--可以设置编码，读取中文，英文，数字
      public String readFileContent(String path,String encoding) throws IOException{ //参数: 路径,编码格式
        StringBuilder sb =new StringBuilder();
          
          //定位文件
          File f=new File(path);
          FileInputStream fip=new FileInputStream(f);
          InputStreamReader reader=new InputStreamReader(fip,encoding);
          
          while(reader.ready()){
            sb.append((char)reader.read());
          }
          
        return sb.toString(); 
       }    
    
    
    
    //功能3: 获得路径，创建目录
    public void createFile(String path){
      File d=new File(path);
          d.mkdir();
    }
    
    //功能4: 创建文件,写入内容
    public void cFile(String path,String fileName,String encoding,String content) throws IOException{ //参数：路径,文件名.格式,编码格式,文件内容
      File f=new File(path+"/"+fileName);
      FileOutputStream fop= new FileOutputStream(f);
      OutputStreamWriter writer=new OutputStreamWriter(fop,"UTF-8");
      
      writer.append(content);
      
      writer.close();
      fop.close();
      System.out.println("文件创建完毕");
    }
    
    
    //功能5: 自定义创建目录(标准格式提交,例如:刘淑玮-第二批(02307-02370))
    public void cList(String path,String fileName,String province) throws Exception{ //参数：路径 ,文件名
      
        //一.创建对象  1.连接数据库  2.改变文件
        UseDB u =new UseDB();
        u.connDatabase();
        ChangeFile cf=new ChangeFile(u);
      
        //二.创建父目录
        String dir=path+"/"+fileName;
        createFile(dir);
            
        //三.获得编号,储存起始编号，终止编号
            String number=fileName.substring(fileName.indexOf("(")+1,fileName.lastIndexOf(")"));
            String [] num=number.split("-");
            int first=Integer.parseInt(num[0]);
            int last=Integer.parseInt(num[1]);
            
            //获取使用者名字
            String username=fileName.substring(0,fileName.indexOf("-"));
              
            
            //四.查询webapi表里num字段所有记录，将其保存在数组里
            u.useDatabase("my_blog");//使用my_blog数据库
            String allNum=u.selectNum("webapi","num");
          String [] allNumA=allNum.split("&");
           
          //五.计算webapi中num个数(包括带-的)
          int sum=0;
          String allNumber=u.selectNum("webapi","num");
          String [] allNumber_Arrays=allNumber.split("&");
          for(int i=0;i<allNumber_Arrays.length;i++){
            if(i>1){
              if(!allNumber_Arrays[i].substring(0,5).equals(allNumber_Arrays[i-1].substring(0,5)))
                sum++;
              else
                continue;
            }
          }
            
            //六.生成1级子目录      规格:"接口(n个)&入库(n个)&入库-增量(n个)"
                
                String [] str={"接口","入库","入库-增量"};
                String sonFile=null;//1级子目录
                String sonFile2=null;//2级子目录
                String ifNum=null;//2级目录判定编号
                
                for(int i=0;i<str.length;i++){   
                  sonFile=dir+"/"+str[i]+"("+sum+")";//路径
                  this.createFile(sonFile);  //循环创建1级子目录
                  
                  //进入含有"入库"字样的二级字目录
                  if(str[i].indexOf("入库")!=-1){
                    //生成入库编号
                    for(int j=first;j<=last;j++){ //循环次数：终止编号-起始编号
                      for(int k=0;k<allNumA.length;k++){ //循环次数：数据库webapi表里num记录的数量
                        
                        ifNum=allNumA[k].substring(1,5);
                        if(ifNum.equals(j+"")){   //对比输入编号和Excel表里的编号
                          
                          sonFile2=sonFile+"/入库-0"+j; 
                          createFile(sonFile2); //创建2级子目录
                          
                          if(k==0)
                            cf.createBackupTask(sonFile2+"/",province,allNumA[k],allNumA[0]);//创建BackupTask.java
                          else
                            cf.createBackupTask(sonFile2+"/",province,allNumA[k],allNumA[k-1]);//创建BackupTask.java
                          
                          sonFile2=sonFile2+"/imp";
                          createFile(sonFile2);//创建3级子目录
                          if(str[i].indexOf("入库-增量")!=-1) continue;  //增量不生成入库代码
                          cf.combineCreateRukuCoding(sonFile2+"/",province,allNumA[k],username);
                        }
                      }

                    }
                  }
                }
            
           System.out.println(fileName+"目录生成完毕!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
           u.closeAll();//关闭资源
    }
    
    

    
    
}


```


---


五.ChangeFile.java
-----------------
```
package review;

import java.io.IOException;


public class ChangeFile {
  
  private String zhaobYgService="zhaobYgService";     //招标预告
  private String zhaobGgService="zhaobGgService";   //招标公告
  private String zisJgService="zisJgService";     //咨审结果
  private String zhaobWjService="zhaobWjService";   //招标文件
  private String gonggBgService="gonggBgService";   //公告变更
  private String zhaobDyService="zhaobDyService";     //招标答疑
  private String zhongbXxService="zhongbXxService"; //中标信息
  private String kongZjService="kongZjService";   //控制价
  
  private String model; //BackupTask模版语句

  
  private UseDB udb;
  private IOFile iof;
  
  //getter和Setter方法
  public String getModel(){
    return model;
  }
  public void setModel(String model){
    this.model=model;
  }

  
  //无参构造方法
  public ChangeFile(UseDB u) throws Exception{
    String model="NameA=(NameB) ac.getBean(\"fileName\");";
    String model2="NameA.initNameB();";
    this.setModel("\n\t\t"+model+"\n\t\t"+model2+"\n\t\t");//换行和空格Tab
    
    udb=u;
    iof=new IOFile();
  }
  
  
  //工具1:将首字母变为大写
  public String UpFirstString(String content){ //参数: 内容
    String firstLetter=content.substring(0,1);
    //替换首字母
    content=content.replaceFirst(firstLetter,firstLetter.toUpperCase());
    return content;
  }
  
  //工具1-2:将首字母变为小写
  public String LowFirstString(String content){ //参数: 内容
    String firstLetter=content.substring(0,1);
    //替换首字母
    content=content.replaceFirst(firstLetter,firstLetter.toLowerCase());
    return content;
  }
  
  //工具2:自动生成文件名    
  public String cFileName(String province,String num,String attributeName){//参数:省份拼音缩写(大写),编号,相应的属性名
    StringBuilder sb= new StringBuilder();
    
    num=num.replace("-","_");
    attributeName=UpFirstString(attributeName);
    sb.append(LowFirstString(province)+"_"+num+"_"+attributeName);
    
    return sb.toString();
  }
  
  //工具3:根据BackupTask模版语句,生成相应字符串
  public String cModelString(String province,String num,String attributeName){//参数: 省份,编号,相应的属性名
    StringBuilder sb=new StringBuilder();
    
    
    String fileName=cFileName(province,num,attributeName);
    String cStr=getModel();
    cStr=cStr.replace("NameA",attributeName).replace("NameB",UpFirstString(attributeName)).replace("fileName",fileName);
    
    sb.append(cStr);
    return sb.toString();
  }
  
  //工具4:生成内容注解
  public String cContentNode(String infSource,String modelName,String num){
    StringBuilder sb= new StringBuilder();
    
    //根据模版名字判断类型
    String type="";
    
    if(modelName.equals("zbyg")){
      type="招标预告";
    }else if(modelName.equals("zbgg")){
      type="招标公告";
    }else if(modelName.equals("zsjg")){
      type="咨审结果";
    }else if(modelName.equals("ggbg")){
      type="公告变更";
    }else if(modelName.equals("zbwj")){
      type="招标文件";
    }else if(modelName.equals("zbdy")){
      type="招标答疑";
    }else if(modelName.equals("zbxx")){
      type="中标信息";
    }else if(modelName.equals("kzj")){
      type="招标控制价";
    } 
    
    sb.append("东软一期-"+infSource+"-"+type+"-"+num);
    
    return sb.toString();
  }
  
  
  //工具5: 判断一个编号有需要创建哪些入库代码，循环调用createRukuCoding方法进行
  public void combineCreateRukuCoding(String path,String province,String num,String username){//路径,省份拼音首字母(大写),编号，程旭猿
    
    
    //查询数据库，确认类型
    String type="";
    
    String ifURL=udb.checktable(num);
    String [] ifURL_Arrays=ifURL.split("&");
    for(int i=0;i<ifURL_Arrays.length;i++){
      createRukuCoding(path,province,num,ifURL_Arrays[i],username);
    }
  }
  
  
  //功能1:创建BackupTask.java                                                        (上一个编号，用来处理-)
  public void createBackupTask (String path,String province,String num,String ageNum){//参数: 路径,省份拼音缩写,编号,上一个编号

    //一.检查数据库webapi表,对应num(编号)的整条记录，招标预告-招标公告哪个字段有URL
    String ifURL=udb.checktable(num);
    String [] ownURLArrays=ifURL.split("&");
    
    //二.生成相应内容
    String content=""; //储存总体字符串
    String str="";     //中转字符串
    if(ownURLArrays.length==0){
      System.out.println("这个编号为空，不存在url，跳过");
    }else{
      for(int i=0;i<ownURLArrays.length;i++)  //webapi表格里有url的字段
      {
        
        if(ownURLArrays[i].equals("zbyg")){
          str=cModelString(province,num,zhaobYgService);
        }else if(ownURLArrays[i].equals("zbgg")){
          str=cModelString(province,num,zhaobGgService);
        }else if(ownURLArrays[i].equals("zsjg")){
          str=cModelString(province,num,zisJgService);
        }else if(ownURLArrays[i].equals("ggbg")){
          str=cModelString(province,num,gonggBgService);
        }else if(ownURLArrays[i].equals("zbwj")){
          str=cModelString(province,num,zhaobWjService);
        }else if(ownURLArrays[i].equals("zbdy")){
          str=cModelString(province,num,zhaobDyService);
        }else if(ownURLArrays[i].equals("zbxx")){
          str=cModelString(province,num,zhongbXxService);
        }else if(ownURLArrays[i].equals("kzj")){
          str=cModelString(province,num,kongZjService);
        }
                
        content+=str;
      }
      content+="//ok;";
     }

    //三.判断当前编号是否和上一个编号相同
    boolean sign=false;//设立标示
    if(num.equals(ageNum) || !num.substring(0,5).equals(ageNum.substring(0,5))){
      sign=true;
    }
    
    //四.根据数据库表article表中模版，生成相应编号的文件
    try{
      String dbModelBackupTask=udb.select("article","detail","model='BackupTask'"); //储存数据库article表中,BackupTask模版
    
      if(sign){
        //与上一个编号完全不同(号码不同,且不带-)
        dbModelBackupTask=dbModelBackupTask.replace("//changeModel;",content);
        iof.cFile(path,"BackupTask.java","UTF-8",dbModelBackupTask);//路径,文件名,编码格式,内容
      
      }else{
        //带-的编号,在上一个文件基础上进行叠加
        String ageContent=iof.readFileContent(path+"/BackupTask.java","UTF-8");//前一个编号的内容   
        String changeContent=ageContent.replace("//ok;",content);
        iof.cFile(path,"BackupTask.java","UTF-8",changeContent);
      }
      
    }catch(Exception e){
      e.printStackTrace();
    }
  }
  
  //功能1:创建相应编号,类型的入库代码
  public void createRukuCoding(String path,String province,String num,String type,String username){//参数: 路径,省份拼音首字母缩写,编号,类型,程序猿
    
        //一.生成文件名
        String fileName=""; //注解名
        String typeSpell="";
        String typeService="";
        
          for(int i=0;i<8;i++)  //共8种类型
          {       
            if(type.equals("zbyg")){
              fileName=cFileName(province,num,zhaobYgService);
              typeSpell="zhaoBiaoYuGao";
              typeService="zhaobYgService";
            }else if(type.equals("zbgg")){
              fileName=cFileName(province,num,zhaobGgService);
              typeSpell="zhaoBiaoGongGao";
              typeService="zhaobGgService";
            }else if(type.equals("zsjg")){
              fileName=cFileName(province,num,zisJgService);
              typeSpell="ziShenJieGuo";
              typeService="zisJgService";
            }else if(type.equals("ggbg")){
              fileName=cFileName(province,num,gonggBgService);
              typeSpell="gongGaoBianGeng";
              typeService="gonggBgService";
            }else if(type.equals("zbwj")){
              fileName=cFileName(province,num,zhaobWjService);
              typeSpell="";
              typeService="zhaobWjService";
            }else if(type.equals("zbdy")){
              fileName=cFileName(province,num,zhaobDyService);
              typeSpell="zhaoBiaoWenJian";
              typeService="zhaobDyService";
            }else if(type.equals("zbxx")){
              fileName=cFileName(province,num,zhongbXxService);
              typeSpell="zhongBiaoXinXi";
              typeService="zhongbXxService";
            }else if(type.equals("kzj")){
              fileName=cFileName(province,num,kongZjService);
              typeSpell="kongZhiJia";
              typeService="kongZjService";
            }       
         }
          
        //首字母变为小写
        String fileNameL=LowFirstString(fileName);
        
        //首字母变为大写
        String typeSpellUp=UpFirstString(typeSpell);
        String typeServiceUp=UpFirstString(typeService);
          
        //二.查询数据库模版
        String modelName=fileName.substring(fileName.lastIndexOf("_")+1);
        String modelContent=udb.select("article","detail","model='ZhaobGgServiceModel'");
        
        //三.查询数据库num编号的整行记录,所需要要的信息
        String information_num=udb.selectNeedInformation_num(num);
        String [] information_Arrays=information_num.split("&");
        
        String area=information_Arrays[0];                      //区域
        String provinceDB=information_Arrays[1].replace("省","");          //省份(不要省字)
        String city=information_Arrays[2].replace("市","");              //城市(不要市字)
        String county=information_Arrays[3].replace("区","").replace("县","");    //区县(不要区,县字)
        String webname=information_Arrays[4];                   //网站名称
        String infsource=information_Arrays[5];                   //信息来源
        
        //三.生成顶部内容注解
        String contentNode=cContentNode(infsource,type,num);
        
        //四.修改模版
        String rukuContent=modelContent.replace("zhaoBiaoGongGao",typeSpell).replace("ZhaoBiaoGongGao",typeSpellUp).replace("ZhaobGgService",typeServiceUp).replace("zhaobGgService",typeService).replace("zbgg",type);
        //程序猿;
        rukuContent=rukuContent.replaceFirst("//程序猿;",username).replaceFirst("//注解内容;",contentNode);
        rukuContent=rukuContent.replaceFirst("//注解;",fileNameL).replaceFirst("//类名;",fileName);
        
        rukuContent=rukuContent.replaceFirst("//编号;",num);
        
        rukuContent=rukuContent.replaceFirst("//area;",area);
        rukuContent=rukuContent.replaceFirst("//provinceDB;",provinceDB);
        rukuContent=rukuContent.replaceFirst("//city;",city);
        rukuContent=rukuContent.replaceFirst("//county;",county);
        rukuContent=rukuContent.replaceFirst("//webname;",webname);
        rukuContent=rukuContent.replaceFirst("//infsource;",infsource);
        
        try{
          //创建文件
          iof.cFile(path,fileName+".java","UTF-8",rukuContent);//路径,文件名,编码格式,内容
        }catch(IOException e){
          e.printStackTrace();
        }
        
  }
}


```






六.两套java文件模版
--------------------------
1.BackupTaskt.java
```
package com.bonait.dataextract.scheduler;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.bonait.dataextract.service.GonggBgService;
import com.bonait.dataextract.service.KongZjService;
import com.bonait.dataextract.service.ZhaobDyService;
import com.bonait.dataextract.service.ZhaobGgService;
import com.bonait.dataextract.service.ZhaobWjService;
import com.bonait.dataextract.service.ZhaobYgService;
import com.bonait.dataextract.service.ZhongbXxService;
import com.bonait.dataextract.service.ZisJgService;

public class BackupTask extends QuartzJobBean {

  private static ZhaobGgService zhaobGgService;
  private static ZhongbXxService zhongbXxService;
  private static ZhaobWjService zhaobWjService;
  private static ZhaobDyService zhaobDyService;
  private static ZisJgService zisJgService;
  private static GonggBgService gonggBgService;
  private static KongZjService kongZjService;
  private static ZhaobYgService zhaobYgService;
  

  @Override
  protected void executeInternal(JobExecutionContext arg0)
      throws JobExecutionException {
  }

  public static void main(String[] args) {
    ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");
    
    //changeModel;
    
  }
}
```

---

2.ZhaobGgServiceModel.java
```
package com.bonait.dataextract.service.impl;
import javax.annotation.Resource;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Service;

import com.bonait.dataextract.dao.BaseDao;
import com.bonait.dataextract.domain.*;
import com.bonait.dataextract.service.*;
import com.bonait.dataextract.util.Util;
import com.bonait.dataextract.vo.*;


/**
 * @程序猿：//程序猿;
 * 
 * @内容：//注解内容;
 */
@Service("//注解;")
public class //类名; implements ZhaobGgService{

  @Resource
  private SessionFactory sf ;
  private Query query;
  private ZhaoBiaoGongGao zbgg;
  //列表页接口地址
  private String listUrl="";
  //内容页接口地址
  private String detailUrl="";
  //入库编码
  private String sourceNo="//编号;";
  @Override
  public void initZhaobGgService() {
    try{
            //获取总页数
          String s=Util.sendGet(listUrl,"1");
          JSONObject obj =JSONObject.fromObject(s);
          while (null == obj.get("pageCount")){
           s = Util.sendGet(listUrl, "1");
           obj = JSONObject.fromObject(s);
          }
    int maxPage=Integer.parseInt(obj.get("pageCount").toString());


    Session session=sf.openSession();
    session.beginTransaction();

    //清空数据库里
//    query=session.createSQLQuery("DELETE FROM t_zhao_biao_gong_gao t where t.WEB_SOURCE_NO='"+sourceNo+"'");
//    query.executeUpdate();
//    session.getTransaction().commit();
//    session.beginTransaction();


    int KK=0;
      flag:
      for(int i=1;i<=maxPage;i++){//maxPage
        String jsonList=Util.sendGet(listUrl,i+"");
        JSONObject objList =JSONObject.fromObject(jsonList);

        while(null == objList.get("list")){
          jsonList = Util.sendGet(listUrl, i + "");
          objList = JSONObject.fromObject(jsonList);
        }

        JSONArray temp=(JSONArray) objList.get("list");
        List list = (List)JSONArray.toList(temp,ListVO.class);
        Iterator it = list.iterator();

        int rows = 1;
        for(int row =1;row < rows;row++){
          it.next();
        }

        while(it.hasNext()){
          ListVO listvo =(ListVO) it.next();
          query=session.createSQLQuery("SELECT ID FROM t_zhao_biao_gong_gao t where t.WEB_SOURCE_NO='"+sourceNo+"' and t.RECORD_ID='"+listvo.getId()+"'");
          String getDate=listvo.getDate();
          //获取页数，便于插入数据异常时，先跳过该页
          System.out.println(i+":"+getDate+":"+maxPage);
          
              int date = Integer.parseInt(getDate.substring(0, 4));
              //只取2014年至今的不重复数据 
            if(query.executeUpdate()<=0&&date>=2014){
              KK+=1;
              String detail = null;
            JSONObject o = null;
            String content = null;
            while (content == null || content.length() < 10) {
              detail = Util.sendGet(detailUrl, listvo.getId());
              if (null != detail)
                o = JSONObject.fromObject(detail);
              else
                continue;
              if (null != o&&null != o.get("content"))
                content = o.get("content").toString();
              else
                continue;
              System.out.println("runing..");
            }
              //过滤掉无效数据
              if(content==null||content.length()<10||content.contains("出错")||content.contains("找不到文件")){continue;}
              zbgg=new ZhaoBiaoGongGao();
              zbgg.setWebSourceNo(sourceNo);
              zbgg.setArea("//area;");//区域
              zbgg.setProvince("//provinceDB;");//省份
              zbgg.setCity("//city;");//城市，没有可不填
              zbgg.setDistrict("//county;");// 区县 不要“区”字符
//              zbgg.setCity(listvo.getCiy());
              zbgg.setWebSourceName("//webname;");//网站名称，写完整的名称
              zbgg.setInfoSource("//infsource;");//信息来源
              //未匹配到工程或服务的，都标识为货物
                String infoType=Util.getInfoType(content);
                if(infoType!=null&&infoType.length()>0)
                zbgg.setInfoType(Util.getInfoType(content));
                else {zbgg.setInfoType("货物");}
//              zbgg.setInfoType("服务");//信息类型
//              zbgg.setIndustry("建筑建材"); //行业分类
//              zbgg.setIndustry(Util.getIndustry(content));//行业分类
              zbgg.setRecordId(listvo.getId());
              zbgg.setId(UUID.randomUUID().toString());
              zbgg.setPageTitle(listvo.getTitle());
              zbgg.setPageTime(getDate);
              zbgg.setPageContent(content);
              zbgg.setPageAttachments("");//附件url，暂不需要
              zbgg.setCreateTime(new Date());
            session.save(zbgg);
             }else if(date<=2013){break flag;}//到2013年的页码时，断掉循环
            if(KK%1==0){
              session.flush();  
              session.clear();
              session.getTransaction().commit();
              session.beginTransaction();
            }
        }  
      } 

      
    session.getTransaction().commit();
    session.close();
    System.out.println("000000000");
    
    } catch (Exception e) {
      System.out.println(sourceNo+"接口出错，请检查");
    }
  }

}

```


---


七.设计数据库
----------------------------------

数据库:Mysql 5.7
数据库工具:Navicat for MySQL10.7
JDBC-Mysql驱动包版本:mysql-connector-java-5.1.38-bin.jar


1,创建速据库
`create database my_blog`

```

---

2.创建表article(用于保存模版)
```
 CREATE TABLE article(             
    id INT  AUTO_INCREMENT primary key,
    model VARCHAR(30) NOT NULL,
    detail VARCHAR(20000) NOT NULL,
    date DATETIME DEFAULT NOW()
)ENGINE = innoDB DEFAULT CHARSET=utf8;
```

---

3.创建webapi(导入excel表格数据,保存进该表)
```
CREATE TABLE webapi(             
    num VARCHAR(20) primary key,
    area VARCHAR(255) NOT NULL,
    province VARCHAR(255) NOT NULL,
    city VARCHAR(255) NOT NULL,
    county VARCHAR(255) NOT NULL,
    webname VARCHAR(255)  NOT NULL,
    weburl  VARCHAR(255)  NOT NULL,
    infsource VARCHAR(255) NOT NULL,
    inftype   VARCHAR(255),
    worktype VARCHAR(255),
    zbyg  VARCHAR(255),
    zbgg    VARCHAR(255),
    zsjg  VARCHAR(255),
    ggbg VARCHAR(255),
    zbwj VARCHAR(255),
    zbdy VARCHAR(255),
    zbxx VARCHAR(255),
    kzj VARCHAR(255)
)ENGINE = innoDB DEFAULT CHARSET=utf8;
```

---


3-2使用 navicat for MySQL工具导入Excel表格到数据库自动生成

>操作步骤：
>>打开工具--->连接数据库--->左键双击选择数据库--->右键子菜单的表---->导入向导---->
-------->选择Excel文件(2007或者以上版本)(*.xlsx)，下一步,之后根据提示操作即可

```
查看webapi表结构的命令：  
show create table webapi;

CREATE TABLE `webapi` (
  `num` varchar(255) NOT NULL,
  `area` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `county` varchar(255) DEFAULT NULL,
  `webname` varchar(255) DEFAULT NULL,
  `weburl` varchar(255) DEFAULT NULL,
  `infsource` varchar(255) DEFAULT NULL,
  `inftype` varchar(255) DEFAULT NULL,
  `worktype` varchar(255) DEFAULT NULL,
  `zbyg` varchar(255) DEFAULT NULL,
  `zbgg` varchar(255) DEFAULT NULL,
  `zsjg` varchar(255) DEFAULT NULL,
  `ggbg` varchar(255) DEFAULT NULL,
  `zbwj` varchar(255) DEFAULT NULL,
  `zbdy` varchar(255) DEFAULT NULL,
  `zbxx` varchar(255) DEFAULT NULL,
  `kzj` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
```

